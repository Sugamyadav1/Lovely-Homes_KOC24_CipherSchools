# Propety Website

## Techology Used
- HTML
- CSS
- JavaScipt

## Page Demo

- ### Home Page

  This is the homepage of our website where user can search property according to their budget and place
![Screenshot_2022-12-04_11_24_22](https://user-images.githubusercontent.com/66194302/205477350-07f94b8f-c290-4e8e-bc08-c08e80482fcd.png)


- ### Buy Page

  This is the buy page of owr website where the search products from the users will be listed
  
  ![Screenshot_2022-12-04_11_24_54](https://user-images.githubusercontent.com/66194302/205477374-240ca598-62c0-4280-8f6b-ec6e5af87bba.png)


- ### Login Popup

  This is the login popup of owr website from where user can either sign up or login to the website so the purchage and login or work anything on the website
  
  ![Screenshot_2022-12-04_11_24_42](https://user-images.githubusercontent.com/66194302/205477431-48f40b2e-90f3-426a-a2d4-e480487f0c2a.png)


- ### Contact us Page

  This is the contact us page of our website from where a customer can contact with us
  ![Screenshot_2022-12-04_11_25_17](https://user-images.githubusercontent.com/66194302/205477485-fc966bda-95fc-467a-972a-83c33861ba24.png)


- ### Sell Page

  This is the sell page of website from a property owner can contact us and list their property for advertisement
  
  ![Screenshot_2022-12-04_11_25_06](https://user-images.githubusercontent.com/66194302/205477541-43acfd9f-03cc-45e7-b6f2-6bbfaa0f10ec.png)


- ### Here is demo video of working of the website
     https://youtu.be/czKSSfvz6g8
