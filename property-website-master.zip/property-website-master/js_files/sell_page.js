
const func4 = () => {
    document.getElementById('id1').style.backgroundColor = '#d8232a'
    document.getElementById('id1').style.color = '#ffff'
    document.getElementById('id2').style.backgroundColor = '#ffff'
    document.getElementById('id2').style.color = 'black'
    document.getElementById('id3').style.color = 'black'
    document.getElementById('id3').style.backgroundColor = '#ffff'
}
const func5 = () => {
    document.getElementById('id2').style.backgroundColor = '#d8232a'
    document.getElementById('id2').style.color = '#ffff'
    document.getElementById('id1').style.backgroundColor = '#ffff'
    document.getElementById('id1').style.color = 'black'
    document.getElementById('id3').style.color = 'black'
    document.getElementById('id3').style.backgroundColor = '#ffff'
}
const func6 = () => {
    document.getElementById('id3').style.backgroundColor = '#d8232a'
    document.getElementById('id3').style.color = '#ffff'
    document.getElementById('id2').style.backgroundColor = '#ffff'
    document.getElementById('id2').style.color = 'black'
    document.getElementById('id1').style.color = 'black'
    document.getElementById('id1').style.backgroundColor = '#ffff'
}
const func7 = () => {
    document.getElementById('id4').style.backgroundColor = '#d8232a'
    document.getElementById('id4').style.color = '#ffff'
    const clickable = ['id5', 'id6', 'id7', 'id8', 'id9', 'id10', 'id11'];
    for (let i = 0; i < clickable.length; i++) {
        document.getElementById(clickable[i]).style.color = 'black'
        document.getElementById(clickable[i]).style.backgroundColor = '#ffff'
    }
}
const func8 = () => {
    document.getElementById('id5').style.backgroundColor = '#d8232a'
    document.getElementById('id5').style.color = '#ffff'
    const clickable = ['id4', 'id6', 'id7', 'id8', 'id9', 'id10', 'id11'];
    for (let i = 0; i < clickable.length; i++) {
        document.getElementById(clickable[i]).style.color = 'black'
        document.getElementById(clickable[i]).style.backgroundColor = '#ffff'
    }
}
const func9 = () => {
    document.getElementById('id6').style.backgroundColor = '#d8232a'
    document.getElementById('id6').style.color = '#ffff'
    const clickable = ['id4', 'id5', 'id7', 'id8', 'id9', 'id10', 'id11'];
    for (let i = 0; i < clickable.length; i++) {
        document.getElementById(clickable[i]).style.color = 'black'
        document.getElementById(clickable[i]).style.backgroundColor = '#ffff'
    }
}
const func10 = () => {
    document.getElementById('id7').style.backgroundColor = '#d8232a'
    document.getElementById('id7').style.color = '#ffff'
    const clickable = ['id4', 'id5', 'id6', 'id8', 'id9', 'id10', 'id11'];
    for (let i = 0; i < clickable.length; i++) {
        document.getElementById(clickable[i]).style.color = 'black'
        document.getElementById(clickable[i]).style.backgroundColor = '#ffff'
    }
}
const func11 = () => {
    document.getElementById('id8').style.backgroundColor = '#d8232a'
    document.getElementById('id8').style.color = '#ffff'
    const clickable = ['id4', 'id5', 'id6', 'id7', 'id9', 'id10', 'id11'];
    for (let i = 0; i < clickable.length; i++) {
        document.getElementById(clickable[i]).style.color = 'black'
        document.getElementById(clickable[i]).style.backgroundColor = '#ffff'
    }
}
const func12 = () => {
    document.getElementById('id9').style.backgroundColor = '#d8232a'
    document.getElementById('id9').style.color = '#ffff'
    const clickable = ['id4', 'id5', 'id6', 'id7', 'id8', 'id10', 'id11'];
    for (let i = 0; i < clickable.length; i++) {
        document.getElementById(clickable[i]).style.color = 'black'
        document.getElementById(clickable[i]).style.backgroundColor = '#ffff'
    }
}
const func13 = () => {
    document.getElementById('id10').style.backgroundColor = '#d8232a'
    document.getElementById('id10').style.color = '#ffff'
    const clickable = ['id4', 'id5', 'id6', 'id7', 'id8', 'id9', 'id11'];
    for (let i = 0; i < clickable.length; i++) {
        document.getElementById(clickable[i]).style.color = 'black'
        document.getElementById(clickable[i]).style.backgroundColor = '#ffff'
    }
}
const func14 = () => {
    document.getElementById('id11').style.backgroundColor = '#d8232a'
    document.getElementById('id11').style.color = '#ffff'
    const clickable = ['id4', 'id5', 'id6', 'id7', 'id8', 'id9', 'id10'];
    for (let i = 0; i < clickable.length; i++) {
        document.getElementById(clickable[i]).style.color = 'black'
        document.getElementById(clickable[i]).style.backgroundColor = '#ffff'
    }
}
