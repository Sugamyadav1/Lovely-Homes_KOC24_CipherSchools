
const func17 = () => {
    document.getElementById('search_id1').style.color = '#d8232a'
    document.getElementById('search_id1').style.fontFamily = 'Open Sans'
    document.getElementById('search_id1').style.borderColor = '#d8232a'
    document.getElementById('search_id1').style.fontWeight = '700'
    const id_s = ['search_id2', 'search_id3', 'search_id4', 'search_id5', 'search_id6', 'search_id7']
    for (let i = 0; i < id_s.length; i++) {
        document.getElementById(id_s[i]).style.color = 'black'
        document.getElementById(id_s[i]).style.fontFamily = "'Noto Sans', sans-serif"
        document.getElementById(id_s[i]).style.borderColor = 'white'
        document.getElementById(id_s[i]).style.fontWeight = 'bold'
    }
}
const func18 = () => {
    document.getElementById('search_id2').style.color = '#d8232a'
    document.getElementById('search_id2').style.fontFamily = 'Open Sans'
    document.getElementById('search_id2').style.borderColor = '#d8232a'
    document.getElementById('search_id2').style.fontWeight = '700'
    const id_s = ['search_id1', 'search_id3', 'search_id4', 'search_id5', 'search_id6', 'search_id7']
    for (let i = 0; i < id_s.length; i++) {
        document.getElementById(id_s[i]).style.color = 'black'
        document.getElementById(id_s[i]).style.fontFamily = "'Noto Sans', sans-serif"
        document.getElementById(id_s[i]).style.borderColor = 'white'
        document.getElementById(id_s[i]).style.fontWeight = 'bold'
    }
}
const func19 = () => {
    document.getElementById('search_id3').style.color = '#d8232a'
    document.getElementById('search_id3').style.fontFamily = 'Open Sans'
    document.getElementById('search_id3').style.borderColor = '#d8232a'
    document.getElementById('search_id3').style.fontWeight = '700'
    const id_s = ['search_id2', 'search_id1', 'search_id4', 'search_id5', 'search_id6', 'search_id7']
    for (let i = 0; i < id_s.length; i++) {
        document.getElementById(id_s[i]).style.color = 'black'
        document.getElementById(id_s[i]).style.fontFamily = "'Noto Sans', sans-serif"
        document.getElementById(id_s[i]).style.borderColor = 'white'
        document.getElementById(id_s[i]).style.fontWeight = 'bold'
    }
}
const func20 = () => {
    document.getElementById('search_id4').style.color = '#d8232a'
    document.getElementById('search_id4').style.fontFamily = 'Open Sans'
    document.getElementById('search_id4').style.borderColor = '#d8232a'
    document.getElementById('search_id4').style.fontWeight = '700'
    const id_s = ['search_id2', 'search_id3', 'search_id1', 'search_id5', 'search_id6', 'search_id7']
    for (let i = 0; i < id_s.length; i++) {
        document.getElementById(id_s[i]).style.color = 'black'
        document.getElementById(id_s[i]).style.fontFamily = "'Noto Sans', sans-serif"
        document.getElementById(id_s[i]).style.borderColor = 'white'
        document.getElementById(id_s[i]).style.fontWeight = 'bold'
    }
}
const func21 = () => {
    document.getElementById('search_id5').style.color = '#d8232a'
    document.getElementById('search_id5').style.fontFamily = 'Open Sans'
    document.getElementById('search_id5').style.borderColor = '#d8232a'
    document.getElementById('search_id5').style.fontWeight = '700'
    const id_s = ['search_id2', 'search_id3', 'search_id4', 'search_id1', 'search_id6', 'search_id7']
    for (let i = 0; i < id_s.length; i++) {
        document.getElementById(id_s[i]).style.color = 'black'
        document.getElementById(id_s[i]).style.fontFamily = "'Noto Sans', sans-serif"
        document.getElementById(id_s[i]).style.borderColor = 'white'
        document.getElementById(id_s[i]).style.fontWeight = 'bold'
    }
}
const func22 = () => {
    document.getElementById('search_id6').style.color = '#d8232a'
    document.getElementById('search_id6').style.fontFamily = 'Open Sans'
    document.getElementById('search_id6').style.borderColor = '#d8232a'
    document.getElementById('search_id6').style.fontWeight = '700'
    const id_s = ['search_id2', 'search_id3', 'search_id4', 'search_id5', 'search_id1', 'search_id7']
    for (let i = 0; i < id_s.length; i++) {
        document.getElementById(id_s[i]).style.color = 'black'
        document.getElementById(id_s[i]).style.fontFamily = "'Noto Sans', sans-serif"
        document.getElementById(id_s[i]).style.borderColor = 'white'
        document.getElementById(id_s[i]).style.fontWeight = 'bold'
    }
}
const func23 = () => {
    document.getElementById('search_id7').style.color = '#d8232a'
    document.getElementById('search_id7').style.fontFamily = 'Open Sans'
    document.getElementById('search_id7').style.borderColor = '#d8232a'
    document.getElementById('search_id7').style.fontWeight = '700'
    const id_s = ['search_id2', 'search_id3', 'search_id4', 'search_id5', 'search_id6', 'search_id1']
    for (let i = 0; i < id_s.length; i++) {
        document.getElementById(id_s[i]).style.color = 'black'
        document.getElementById(id_s[i]).style.fontFamily = "'Noto Sans', sans-serif"
        document.getElementById(id_s[i]).style.borderColor = 'white'
        document.getElementById(id_s[i]).style.fontWeight = 'bold'
    }
}